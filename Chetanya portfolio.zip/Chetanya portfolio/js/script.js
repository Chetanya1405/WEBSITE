
$(function(){
    $('#menu').slicknav({
        'label':'',
        
        // 'brand':'Bhavdet Verdfma',
        'brand':'<i class="fa-solid fa-code" id="x"></i> Bhavneet Verma'
    });
});



AOS.init();